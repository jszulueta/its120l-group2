class CustomNavbar extends HTMLElement {
    connectedCallback() {
        const user = JSON.parse(localStorage.getItem('currentUser')) || { name: 'Guest', role: 'Visitor' };

        this.innerHTML = `
            <nav class="bg-white shadow-sm border-b z-50 relative">
                <div class="px-4 md:px-8 py-4 flex justify-between items-center">
                    <div class="flex items-center">
                        <button id="mobileMenuBtn" class="md:hidden mr-3 p-2 rounded-lg hover:bg-gray-100">
                            <i data-feather="menu" class="text-gray-600"></i>
                        </button>
                        <i data-feather="book-open" class="text-indigo-600 mr-2"></i>
                        <h1 class="text-lg md:text-xl font-bold text-gray-800">BookMe AI</h1>
                    </div>
                    <div class="flex items-center space-x-2 md:space-x-4">
                        <span class="text-xs md:text-sm text-gray-600 hidden sm:inline">Welcome, ${user.name}</span>
                        <span class="text-xs bg-indigo-100 text-indigo-600 px-2 py-1 rounded">${user.role}</span>
                        <button onclick="logout()" class="text-gray-600 hover:text-gray-800 p-2">
                            <i data-feather="log-out" class="w-5 h-5"></i>
                        </button>
                    </div>
                </div>
            </nav>
            <div id="mobileOverlay" class="fixed inset-0 bg-black bg-opacity-30 hidden z-30"></div>
        `;

        if (typeof feather !== 'undefined') feather.replace();

        const menuBtn = this.querySelector('#mobileMenuBtn');
        const sidebar = document.querySelector('custom-sidebar') || document.querySelector('aside');
        const overlay = this.querySelector('#mobileOverlay');

        if (menuBtn && sidebar && overlay) {
            menuBtn.addEventListener('click', () => {
                sidebar.classList.remove('-translate-x-full');
                sidebar.classList.add('translate-x-0');
                overlay.classList.remove('hidden');
                overlay.classList.add('active');
            });

            overlay.addEventListener('click', () => {
                sidebar.classList.remove('translate-x-0');
                sidebar.classList.add('-translate-x-full');
                overlay.classList.add('hidden');
                overlay.classList.remove('active');
            });
        }
    }
}

customElements.define('custom-navbar', CustomNavbar);
