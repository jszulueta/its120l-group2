class CustomSidebar extends HTMLElement {
    connectedCallback() {
        const user = JSON.parse(localStorage.getItem('currentUser')) || { role: 'Staff' };
        const currentPage = window.location.pathname.split('/').pop() || 'index.html';
        
        const menuItems = [
            { id: 'index.html', label: 'Dashboard', icon: 'bar-chart-2', role: ['Admin', 'Staff', 'Editor', 'Viewer'] },
            { id: 'inventory.html', label: 'Inventory', icon: 'book', role: ['Admin', 'Staff', 'Editor', 'Viewer'] },
            { id: 'forecasts.html', label: 'Forecasts', icon: 'trending-up', role: ['Admin', 'Staff', 'Editor', 'Viewer'] },
            { id: 'alerts.html', label: 'Alerts', icon: 'bell', role: ['Admin', 'Staff', 'Editor', 'Viewer'] },
            { id: 'reports.html', label: 'Reports', icon: 'file-text', role: ['Admin', 'Staff', 'Editor', 'Viewer'] },
            { id: 'users.html', label: 'Users', icon: 'users', role: ['Admin'] },
            { id: 'audit.html', label: 'Audit Logs', icon: 'list', role: ['Admin'] },
            { id: 'settings.html', label: 'Settings', icon: 'settings', role: ['Admin', 'Staff', 'Editor', 'Viewer'] },
        ];
        
        const filteredItems = menuItems.filter(item => item.role.includes(user.role));
        
        this.innerHTML = `
            <aside class="w-64 bg-white border-r min-h-screen p-4 transition-all duration-300">
                <div class="flex justify-between items-center mb-4 md:hidden">
                    <h2 class="font-semibold text-gray-800">Menu</h2>
                    <button id="closeSidebarBtn" class="p-2 rounded-lg hover:bg-gray-100">
                        <i data-feather="x" class="text-gray-600"></i>
                    </button>
                </div>
                <nav class="space-y-2">
                    ${filteredItems.map(item => `
                        <a href="${item.id}" class="sidebar-link w-full flex items-center px-4 py-3 rounded-lg transition ${
                            currentPage === item.id ? 'bg-indigo-50 text-indigo-600' : 'text-gray-700 hover:bg-gray-50'
                        }">
                            <i data-feather="${item.icon}" class="mr-3 w-5 h-5"></i>
                            <span class="text-sm md:text-base">${item.label}</span>
                        </a>
                    `).join('')}
                    <a href="logout.html" class="sidebar-link w-full flex items-center px-4 py-3 rounded-lg transition text-red-600 hover:bg-red-50 md:hidden">
                        <i data-feather="log-out" class="mr-3 w-5 h-5"></i>
                        <span class="text-sm md:text-base">Logout</span>
                    </a>
                </nav>
            </aside>
        `;
        
        // Initialize feather icons
        if (typeof feather !== 'undefined') {
            feather.replace();
        }
        
        // Close sidebar on mobile when clicking a link
        const links = this.querySelectorAll('.sidebar-link');
        const overlay = document.getElementById('mobileOverlay');
        
        links.forEach(link => {
            link.addEventListener('click', () => {
                if (window.innerWidth < 769) {
                    this.classList.remove('mobile-open');
                    if (overlay) overlay.classList.remove('active');
                }
            });
        });
        
        // Close button for mobile
        const closeBtn = this.querySelector('#closeSidebarBtn');
        if (closeBtn) {
            closeBtn.addEventListener('click', () => {
                this.classList.remove('mobile-open');
                if (overlay) overlay.classList.remove('active');
            });
        }
    }
}

customElements.define('custom-sidebar', CustomSidebar);