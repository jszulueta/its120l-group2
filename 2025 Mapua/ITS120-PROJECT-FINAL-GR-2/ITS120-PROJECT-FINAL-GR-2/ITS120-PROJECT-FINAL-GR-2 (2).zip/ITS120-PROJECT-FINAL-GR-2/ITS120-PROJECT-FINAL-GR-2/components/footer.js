class CustomFooter extends HTMLElement {
    connectedCallback() {
        const year = new Date().getFullYear();
        
        this.innerHTML = `
            <footer class="bg-white border-t mt-auto">
                <div class="px-4 md:px-8 py-4">
                    <div class="flex flex-col md:flex-row justify-between items-center text-sm text-gray-500">
                        <p class="mb-2 md:mb-0">&copy; ${year} BookMe AI. All rights reserved.</p>
                        <p class="text-xs md:text-sm">Powered by AI-driven forecasting</p>
                    </div>
                </div>
            </footer>
        `;
    }
}

customElements.define('custom-footer', CustomFooter);