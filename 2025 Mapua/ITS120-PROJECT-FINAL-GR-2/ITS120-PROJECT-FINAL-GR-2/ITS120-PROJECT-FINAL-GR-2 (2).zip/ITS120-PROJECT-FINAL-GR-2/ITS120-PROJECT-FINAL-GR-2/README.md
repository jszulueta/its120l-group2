# Bookme: AI-Driven Inventory Forecasting System

## Description

Bookme is an AI-driven inventory forecasting prototype designed to help small retail businesses predict stock needs and reduce stockouts. This repository contains a static frontend (HTML/CSS/JS) that demonstrates the UI and interactions for inventory, forecasts, reports, users, and alerts.

## Features

- Inventory dashboard and listing
- Forecasts page showing predicted demand
- Alerts for low stock and other conditions
- User management (basic UI)
- Reports and audit pages

## Installation / Run locally

This project is a static website. To run it locally you can either open `index.html` directly in your browser or run a simple local web server (recommended).

Option 1 — open files directly

1. Open the project folder in your file manager.
2. Double-click `index.html` to open it in your default browser.

Option 2 — serve with Python (recommended)

Open a terminal in the project root (where `index.html` is) and run:

```powershell
python -m http.server 8000
```

Then open http://localhost:8000 in your browser.

Option 3 — serve with Node (http-server)

```powershell
npx http-server -p 8000
```

## Screenshots

Add screenshots inside a `docs/screenshots/` folder and embed them below. Example:

![Dashboard placeholder](docs/screenshots/dashboard.png)

## Project structure (important files)

- `index.html` — main entry
- `style.css` — styles
- `script.js` — client-side logic
- `components/` — small JS components (navbar, sidebar, footer)

## Credits

- Team: Group 2 (replace with actual member names)
- Professor: [Professor Name] (replace with instructor name)

Please update the Credits section with the real team member names before submission.

## License

This project is for academic use. You can use the MIT license below if you want:

MIT License

Copyright (c) 2025

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
