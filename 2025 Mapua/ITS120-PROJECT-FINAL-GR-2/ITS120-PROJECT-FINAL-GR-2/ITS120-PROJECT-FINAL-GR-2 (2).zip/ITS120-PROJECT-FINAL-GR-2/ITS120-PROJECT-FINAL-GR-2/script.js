// ====================
// BookMe AI Enhanced Script
// ====================

document.addEventListener('DOMContentLoaded', function () {
    console.log('BookMe AI initialized');
    initializeDemoData();

    // Redirect to login if not authenticated (for protected pages)
    const publicPages = ['login.html', 'register.html', 'logout.html', ''];
    const currentPage = window.location.pathname.split('/').pop();

    if (!publicPages.includes(currentPage)) {
        const user = JSON.parse(localStorage.getItem('currentUser'));
        if (!user) {
            window.location.href = 'login.html';
            return;
        }
    }

    // Initialize mobile menu for all pages
    initializeMobileMenu();

    // Highlight current sidebar link
    const file = currentPage || 'index.html';
    document.querySelectorAll('.sidebar-link').forEach(link => {
        if (link.getAttribute('href') === file) {
            link.classList.add('bg-indigo-50', 'text-indigo-600');
        }
    });

    // Initialize page-specific functionality
    if (currentPage === 'inventory.html') {
        initializeInventory();
    } else if (currentPage === 'users.html') {
        loadUsersTable();
    } else if (currentPage === 'alerts.html') {
        initializeAlerts();
    } else if (currentPage === 'reports.html') {
        initializeReports();
    }
});

// ====================
// Mobile Menu Initialization (Works on ALL pages)
// ====================
function initializeMobileMenu() {
    const menuBtn = document.getElementById('mobileMenuBtn');
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('mobileOverlay');
    const closeBtn = document.getElementById('closeSidebarBtn');

    if (!menuBtn || !sidebar || !overlay) return;

    menuBtn.addEventListener('click', function() {
        sidebar.classList.add('mobile-open');
        overlay.classList.add('active');
    });

    if (closeBtn) {
        closeBtn.addEventListener('click', function() {
            sidebar.classList.remove('mobile-open');
            overlay.classList.remove('active');
        });
    }

    overlay.addEventListener('click', function() {
        sidebar.classList.remove('mobile-open');
        overlay.classList.remove('active');
    });

    // Close on link click (mobile)
    const links = sidebar.querySelectorAll('a');
    links.forEach(function(link) {
        link.addEventListener('click', function() {
            if (window.innerWidth < 769) {
                sidebar.classList.remove('mobile-open');
                overlay.classList.remove('active');
            }
        });
    });
}

// ====================
// Demo Data Initialization
// ====================
function initializeDemoData() {
    if (!localStorage.getItem('users')) {
        localStorage.setItem('users', JSON.stringify([
            { id: 1, name: 'Admin User', email: 'admin@bookme.ai', password: 'admin123', role: 'Admin' },
            { id: 2, name: 'Staff Member', email: 'staff@bookme.ai', password: 'staff123', role: 'Staff' }
        ]));
    }
    
    if (!localStorage.getItem('books')) {
        localStorage.setItem('books', JSON.stringify([
            { id: 1, title: 'The Silent Patient', author: 'Alex Michaelides', category: 'Fiction', isbn: '978-1250301697', price: 12.99, stock: 2, year: 2019 },
            { id: 2, title: 'Atomic Habits', author: 'James Clear', category: 'Non-Fiction', isbn: '978-0735211292', price: 14.99, stock: 42, year: 2018 },
            { id: 3, title: 'Where the Crawdads Sing', author: 'Delia Owens', category: 'Fiction', isbn: '978-0735219090', price: 12.99, stock: 15, year: 2018 },
            { id: 4, title: 'Educated', author: 'Tara Westover', category: 'Biography', isbn: '978-0399590504', price: 13.99, stock: 8, year: 2018 },
            { id: 5, title: 'The Midnight Library', author: 'Matt Haig', category: 'Fiction', isbn: '978-0525559474', price: 13.99, stock: 25, year: 2020 },
            { id: 6, title: 'Sapiens', author: 'Yuval Noah Harari', category: 'Non-Fiction', isbn: '978-0062316097', price: 16.99, stock: 18, year: 2015 },
            { id: 7, title: 'The Power of Now', author: 'Eckhart Tolle', category: 'Non-Fiction', isbn: '978-1577314806', price: 14.99, stock: 30, year: 1997 },
            { id: 8, title: 'Becoming', author: 'Michelle Obama', category: 'Biography', isbn: '978-1524763138', price: 19.99, stock: 22, year: 2018 },
            { id: 9, title: '1984', author: 'George Orwell', category: 'Fiction', isbn: '978-0451524935', price: 9.99, stock: 35, year: 1949 },
            { id: 10, title: 'Harry Potter and the Sorcerer\'s Stone', author: 'J.K. Rowling', category: 'Children', isbn: '978-0439708180', price: 12.99, stock: 45, year: 1997 },
            { id: 11, title: 'The Very Hungry Caterpillar', author: 'Eric Carle', category: 'Children', isbn: '978-0399226908', price: 8.99, stock: 50, year: 1969 },
            { id: 12, title: 'Charlotte\'s Web', author: 'E.B. White', category: 'Children', isbn: '978-0064400558', price: 7.99, stock: 28, year: 1952 },
            { id: 13, title: 'A Brief History of Time', author: 'Stephen Hawking', category: 'Science', isbn: '978-0553380163', price: 15.99, stock: 12, year: 1988 },
            { id: 14, title: 'Cosmos', author: 'Carl Sagan', category: 'Science', isbn: '978-0345539434', price: 17.99, stock: 9, year: 1980 },
            { id: 15, title: 'The Gene', author: 'Siddhartha Mukherjee', category: 'Science', isbn: '978-1476733524', price: 18.99, stock: 14, year: 2016 },
            { id: 16, title: 'Steve Jobs', author: 'Walter Isaacson', category: 'Biography', isbn: '978-1451648539', price: 20.99, stock: 7, year: 2011 },
            { id: 17, title: 'The Diary of a Young Girl', author: 'Anne Frank', category: 'Biography', isbn: '978-0553296983', price: 11.99, stock: 16, year: 1947 },
            { id: 18, title: 'Thinking, Fast and Slow', author: 'Daniel Kahneman', category: 'Non-Fiction', isbn: '978-0374533557', price: 17.99, stock: 20, year: 2011 },
            { id: 19, title: 'The Alchemist', author: 'Paulo Coelho', category: 'Fiction', isbn: '978-0062315007', price: 13.99, stock: 32, year: 1988 },
            { id: 20, title: 'To Kill a Mockingbird', author: 'Harper Lee', category: 'Fiction', isbn: '978-0061120084', price: 10.99, stock: 27, year: 1960 },
            { id: 21, title: 'The Hunger Games', author: 'Suzanne Collins', category: 'Fiction', isbn: '978-0439023481', price: 11.99, stock: 38, year: 2008 },
            { id: 22, title: 'The Da Vinci Code', author: 'Dan Brown', category: 'Fiction', isbn: '978-0307474278', price: 12.99, stock: 19, year: 2003 },
            { id: 23, title: 'The Catcher in the Rye', author: 'J.D. Salinger', category: 'Fiction', isbn: '978-0316769174', price: 10.99, stock: 24, year: 1951 },
            { id: 24, title: 'Pride and Prejudice', author: 'Jane Austen', category: 'Fiction', isbn: '978-0141439518', price: 9.99, stock: 31, year: 1813 },
            { id: 25, title: 'The Hobbit', author: 'J.R.R. Tolkien', category: 'Fiction', isbn: '978-0547928227', price: 14.99, stock: 29, year: 1937 },
            { id: 26, title: 'Matilda', author: 'Roald Dahl', category: 'Children', isbn: '978-0142410370', price: 8.99, stock: 41, year: 1988 },
            { id: 27, title: 'Goodnight Moon', author: 'Margaret Wise Brown', category: 'Children', isbn: '978-0060775858', price: 7.99, stock: 55, year: 1947 },
            { id: 28, title: 'The Cat in the Hat', author: 'Dr. Seuss', category: 'Children', isbn: '978-0394800011', price: 8.99, stock: 48, year: 1957 },
            { id: 29, title: 'Astrophysics for People in a Hurry', author: 'Neil deGrasse Tyson', category: 'Science', isbn: '978-0393609394', price: 15.99, stock: 17, year: 2017 },
            { id: 30, title: 'The Selfish Gene', author: 'Richard Dawkins', category: 'Science', isbn: '978-0198788607', price: 16.99, stock: 11, year: 1976 },
            { id: 31, title: 'Einstein: His Life and Universe', author: 'Walter Isaacson', category: 'Biography', isbn: '978-0743264747', price: 18.99, stock: 13, year: 2007 },
            { id: 32, title: 'Long Walk to Freedom', author: 'Nelson Mandela', category: 'Biography', isbn: '978-0316548182', price: 17.99, stock: 10, year: 1994 },
            { id: 33, title: 'The 7 Habits of Highly Effective People', author: 'Stephen Covey', category: 'Non-Fiction', isbn: '978-1982137274', price: 16.99, stock: 26, year: 1989 },
            { id: 34, title: 'How to Win Friends and Influence People', author: 'Dale Carnegie', category: 'Non-Fiction', isbn: '978-0671027032', price: 15.99, stock: 33, year: 1936 },
            { id: 35, title: 'Rich Dad Poor Dad', author: 'Robert Kiyosaki', category: 'Non-Fiction', isbn: '978-1612680194', price: 14.99, stock: 28, year: 1997 }
        ]));
    }

    if (!localStorage.getItem('notifications')) {
        localStorage.setItem('notifications', JSON.stringify([
            { id: 1, type: 'alert', title: 'Low stock: The Silent Patient', message: 'Only 2 copies remaining. Consider reorder.', time: '2h', read: false },
            { id: 2, type: 'warning', title: 'High forecast: Atomic Habits', message: 'Demand predicted to increase 48% in next 30 days.', time: '6h', read: false },
            { id: 3, type: 'info', title: 'Model updated', message: 'Seasonality parameters recalculated.', time: '1d', read: true }
        ]));
    }

    if (!localStorage.getItem('auditLogs')) {
        localStorage.setItem('auditLogs', JSON.stringify([]));
    }
}

// ====================
// Audit Log Function
// ====================
function addAuditLog(action, entity, details) {
    const user = JSON.parse(localStorage.getItem('currentUser'));
    if (!user) return;

    let logs = JSON.parse(localStorage.getItem('auditLogs')) || [];
    const newLog = {
        id: Date.now(),
        user: user.name,
        action: action,
        entity: entity,
        details: details,
        timestamp: new Date().toISOString()
    };
    logs.unshift(newLog);
    localStorage.setItem('auditLogs', JSON.stringify(logs));
}

// ====================
// Authentication Logic
// ====================
function registerUser(name, email, password, role) {
    let users = JSON.parse(localStorage.getItem('users')) || [];
    if (users.find(u => u.email === email)) {
        alert('User already exists!');
        return false;
    }

    const newUser = { 
        id: Date.now(), 
        name, 
        email, 
        password, 
        role 
    };
    users.push(newUser);
    localStorage.setItem('users', JSON.stringify(users));
    addAuditLog('CREATE', 'User', `Registered new user: ${name} (${role})`);
    alert('Registration successful! You can now log in.');
    window.location.href = 'login.html';
    return true;
}

function loginUser(email, password) {
    let users = JSON.parse(localStorage.getItem('users')) || [];
    const found = users.find(u => u.email === email && u.password === password);

    if (!found) {
        alert('Invalid credentials!');
        return false;
    }

    localStorage.setItem('currentUser', JSON.stringify(found));
    addAuditLog('LOGIN', 'User', `User logged in: ${found.name}`);
    window.location.href = 'index.html';
    return true;
}

function logout() {
    const user = JSON.parse(localStorage.getItem('currentUser'));
    if (user) {
        addAuditLog('LOGOUT', 'User', `User logged out: ${user.name}`);
    }
    localStorage.removeItem('currentUser');
    window.location.href = 'login.html';
}

// ====================
// Inventory Management
// ====================
function initializeInventory() {
    loadInventoryTable();
    setupInventorySearch();
    setupInventoryFilters();
    setupAddBookButton();
}

function loadInventoryTable() {
    const tableBody = document.querySelector('#inventory-table-body');
    if (!tableBody) return;

    const books = JSON.parse(localStorage.getItem('books')) || [];
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    const isAdmin = currentUser && currentUser.role === 'Admin';
    
    tableBody.innerHTML = '';
    
    // Update pagination before rendering
    updatePaginationInfo(books.length);

    books.forEach((book) => {
        const tr = document.createElement('tr');
        const stockStatus = book.stock < 10 ? 
            '<span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">Low Stock</span>' :
            '<span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">In Stock</span>';

        const actionButtons = isAdmin ? `
            <button class="text-indigo-600 hover:text-indigo-900 mr-3" onclick="editBook(${book.id})">
                <i data-feather="edit"></i>
            </button>
            <button class="text-red-600 hover:text-red-900" onclick="deleteBook(${book.id})">
                <i data-feather="trash-2"></i>
            </button>
        ` : `
            <button class="text-gray-400 cursor-not-allowed mr-3" disabled title="Admin only">
                <i data-feather="edit"></i>
            </button>
            <button class="text-gray-400 cursor-not-allowed" disabled title="Admin only">
                <i data-feather="trash-2"></i>
            </button>
        `;

        tr.innerHTML = `
            <td class="px-6 py-4 whitespace-nowrap">
                <div class="flex items-center">
                    <div class="flex-shrink-0 h-10 w-10 bg-blue-100 rounded-lg flex items-center justify-center text-blue-600">
                        <i data-feather="book"></i>
                    </div>
                    <div class="ml-4">
                        <div class="text-sm font-medium text-gray-900">${book.title}</div>
                        <div class="text-sm text-gray-500">${book.year}</div>
                    </div>
                </div>
            </td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${book.author}</td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${book.category}</td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${book.isbn}</td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${book.price}</td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${book.stock}</td>
            <td class="px-6 py-4 whitespace-nowrap">${stockStatus}</td>
            <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                ${actionButtons}
            </td>
        `;
        tableBody.appendChild(tr);
    });

    if (typeof feather !== 'undefined') feather.replace();
}

function setupInventorySearch() {
    const searchInput = document.querySelector('input[placeholder="Search books..."]');
    if (searchInput) {
        searchInput.addEventListener('input', filterInventory);
    }
}

function setupInventoryFilters() {
    const categoryFilter = document.querySelector('select');
    if (categoryFilter) {
        categoryFilter.addEventListener('change', filterInventory);
    }
}

function filterInventory() {
    const searchTerm = document.querySelector('input[placeholder="Search books..."]')?.value.toLowerCase() || '';
    const category = document.querySelector('select')?.value || 'All Categories';
    
    const books = JSON.parse(localStorage.getItem('books')) || [];
    const filtered = books.filter(book => {
        const matchesSearch = book.title.toLowerCase().includes(searchTerm) || 
                             book.author.toLowerCase().includes(searchTerm);
        const matchesCategory = category === 'All Categories' || book.category === category;
        return matchesSearch && matchesCategory;
    });

    displayFilteredBooks(filtered);
}

function displayFilteredBooks(books) {
    const tableBody = document.querySelector('#inventory-table-body');
    if (!tableBody) return;

    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    const isAdmin = currentUser && currentUser.role === 'Admin';

    tableBody.innerHTML = '';
    
    // Update pagination with filtered count
    updatePaginationInfo(books.length);
    
    books.forEach((book) => {
        const tr = document.createElement('tr');
        const stockStatus = book.stock < 10 ? 
            '<span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">Low Stock</span>' :
            '<span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">In Stock</span>';

        const actionButtons = isAdmin ? `
            <button class="text-indigo-600 hover:text-indigo-900 mr-3" onclick="editBook(${book.id})">
                <i data-feather="edit"></i>
            </button>
            <button class="text-red-600 hover:text-red-900" onclick="deleteBook(${book.id})">
                <i data-feather="trash-2"></i>
            </button>
        ` : `
            <button class="text-gray-400 cursor-not-allowed mr-3" disabled title="Admin only">
                <i data-feather="edit"></i>
            </button>
            <button class="text-gray-400 cursor-not-allowed" disabled title="Admin only">
                <i data-feather="trash-2"></i>
            </button>
        `;

        tr.innerHTML = `
            <td class="px-6 py-4 whitespace-nowrap">
                <div class="flex items-center">
                    <div class="flex-shrink-0 h-10 w-10 bg-blue-100 rounded-lg flex items-center justify-center text-blue-600">
                        <i data-feather="book"></i>
                    </div>
                    <div class="ml-4">
                        <div class="text-sm font-medium text-gray-900">${book.title}</div>
                        <div class="text-sm text-gray-500">${book.year}</div>
                    </div>
                </div>
            </td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${book.author}</td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${book.category}</td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${book.isbn}</td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${book.price}</td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${book.stock}</td>
            <td class="px-6 py-4 whitespace-nowrap">${stockStatus}</td>
            <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                ${actionButtons}
            </td>
        `;
        tableBody.appendChild(tr);
    });

    if (typeof feather !== 'undefined') feather.replace();
}

function setupAddBookButton() {
    const addButton = document.querySelector('#addBookBtn');
    if (addButton) {
        addButton.addEventListener('click', function() {
            showBookModal();
        });
    }
}

function showBookModal(bookId = null) {
    const modal = createBookModal(bookId);
    document.body.appendChild(modal);
}

function createBookModal(bookId) {
    const books = JSON.parse(localStorage.getItem('books')) || [];
    const book = bookId ? books.find(b => b.id === bookId) : null;
    
    const modal = document.createElement('div');
    modal.id = 'bookModal';
    modal.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50';
    modal.innerHTML = `
        <div class="bg-white rounded-xl shadow-lg w-full max-w-2xl p-6 max-h-screen overflow-y-auto m-4">
            <h2 class="text-xl font-semibold mb-4">${book ? 'Edit Book' : 'Add New Book'}</h2>
            <form id="bookForm">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div class="col-span-1 md:col-span-2">
                        <label class="block text-sm font-medium text-gray-700">Title</label>
                        <input type="text" id="bookTitle" value="${book ? book.title : ''}" class="mt-1 block w-full border rounded-md px-3 py-2" required>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Author</label>
                        <input type="text" id="bookAuthor" value="${book ? book.author : ''}" class="mt-1 block w-full border rounded-md px-3 py-2" required>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Category</label>
                        <select id="bookCategory" class="mt-1 block w-full border rounded-md px-3 py-2">
                            <option ${book?.category === 'Fiction' ? 'selected' : ''}>Fiction</option>
                            <option ${book?.category === 'Non-Fiction' ? 'selected' : ''}>Non-Fiction</option>
                            <option ${book?.category === 'Children' ? 'selected' : ''}>Children</option>
                            <option ${book?.category === 'Science' ? 'selected' : ''}>Science</option>
                            <option ${book?.category === 'Biography' ? 'selected' : ''}>Biography</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700">ISBN</label>
                        <input type="text" id="bookISBN" value="${book ? book.isbn : ''}" class="mt-1 block w-full border rounded-md px-3 py-2" required>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Year</label>
                        <input type="number" id="bookYear" value="${book ? book.year : ''}" class="mt-1 block w-full border rounded-md px-3 py-2" required>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Price ($)</label>
                        <input type="number" step="0.01" id="bookPrice" value="${book ? book.price : ''}" class="mt-1 block w-full border rounded-md px-3 py-2" required>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Stock</label>
                        <input type="number" id="bookStock" value="${book ? book.stock : ''}" class="mt-1 block w-full border rounded-md px-3 py-2" required>
                    </div>
                </div>
                <div class="flex justify-end space-x-2 mt-6">
                    <button type="button" onclick="closeBookModal()" class="px-4 py-2 bg-gray-100 rounded-lg hover:bg-gray-200">Cancel</button>
                    <button type="submit" class="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700">
                        ${book ? 'Update' : 'Add'} Book
                    </button>
                </div>
            </form>
        </div>
    `;

    modal.querySelector('#bookForm').addEventListener('submit', (e) => {
        e.preventDefault();
        saveBook(bookId);
    });

    return modal;
}

function closeBookModal() {
    const modal = document.getElementById('bookModal');
    if (modal) modal.remove();
}

function saveBook(bookId) {
    const books = JSON.parse(localStorage.getItem('books')) || [];
    
    const bookData = {
        title: document.getElementById('bookTitle').value,
        author: document.getElementById('bookAuthor').value,
        category: document.getElementById('bookCategory').value,
        isbn: document.getElementById('bookISBN').value,
        year: parseInt(document.getElementById('bookYear').value),
        price: parseFloat(document.getElementById('bookPrice').value),
        stock: parseInt(document.getElementById('bookStock').value)
    };

    if (bookId) {
        const index = books.findIndex(b => b.id === bookId);
        books[index] = { ...bookData, id: bookId };
        addAuditLog('UPDATE', 'Book', `Updated book: ${bookData.title}`);
        alert('Book updated successfully!');
    } else {
        const newBook = { ...bookData, id: Date.now() };
        books.push(newBook);
        addAuditLog('CREATE', 'Book', `Added new book: ${bookData.title}`);
        alert('Book added successfully!');
    }

    localStorage.setItem('books', JSON.stringify(books));
    closeBookModal();
    loadInventoryTable();
}

function editBook(bookId) {
    showBookModal(bookId);
}

function deleteBook(bookId) {
    const books = JSON.parse(localStorage.getItem('books')) || [];
    const book = books.find(b => b.id === bookId);
    
    if (confirm(`Are you sure you want to delete "${book.title}"?`)) {
        const updated = books.filter(b => b.id !== bookId);
        localStorage.setItem('books', JSON.stringify(updated));
        addAuditLog('DELETE', 'Book', `Deleted book: ${book.title}`);
        alert('Book deleted successfully!');
        loadInventoryTable();
    }
}

// ====================
// Users Management
// ====================
function loadUsersTable() {
    const tableBody = document.getElementById('users-table-body');
    if (!tableBody) return;

    const users = JSON.parse(localStorage.getItem('users')) || [];
    tableBody.innerHTML = '';

    users.forEach((u) => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td class="px-6 py-4 text-sm font-medium text-gray-900">${u.name}</td>
            <td class="px-6 py-4 text-sm text-gray-500">${u.email}</td>
            <td class="px-6 py-4 text-sm text-gray-500">${u.role}</td>
            <td class="px-6 py-4 text-sm">
                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                    Active
                </span>
            </td>
            <td class="px-6 py-4 text-right text-sm">
                <button class="text-red-600 hover:text-red-900" onclick="deleteUser(${u.id})">
                    <i data-feather='trash-2'></i>
                </button>
            </td>
        `;
        tableBody.appendChild(tr);
    });

    if (typeof feather !== 'undefined') feather.replace();
}

function deleteUser(userId) {
    let users = JSON.parse(localStorage.getItem('users')) || [];
    const current = JSON.parse(localStorage.getItem('currentUser'));
    const user = users.find(u => u.id === userId);
    
    if (user.email === current.email) {
        alert('You cannot delete the currently logged-in user!');
        return;
    }

    if (confirm(`Are you sure you want to delete user "${user.name}"?`)) {
        users = users.filter(u => u.id !== userId);
        localStorage.setItem('users', JSON.stringify(users));
        addAuditLog('DELETE', 'User', `Deleted user: ${user.name}`);
        alert('User deleted successfully!');
        loadUsersTable();
    }
}

// ====================
// Alerts Management
// ====================
function initializeAlerts() {
    setupMarkAllRead();
    loadAlerts();
}

function setupMarkAllRead() {
    const markAllBtn = document.querySelector('button:has(i[data-feather="bell"])');
    if (markAllBtn) {
        markAllBtn.addEventListener('click', markAllAlertsRead);
    }
}

function markAllAlertsRead() {
    let notifications = JSON.parse(localStorage.getItem('notifications')) || [];
    notifications = notifications.map(n => ({ ...n, read: true }));
    localStorage.setItem('notifications', JSON.stringify(notifications));
    alert('All alerts marked as read!');
    loadAlerts();
}

function loadAlerts() {
    console.log('Alerts loaded');
}

// ====================
// Reports Management
// ====================
function initializeReports() {
    setupExportButtons();
}

function setupExportButtons() {
    const exportButtons = document.querySelectorAll('button');
    exportButtons.forEach(btn => {
        if (btn.textContent.includes('Download')) {
            btn.addEventListener('click', () => downloadReport(btn));
        }
    });
}

function downloadReport(button) {
    const books = JSON.parse(localStorage.getItem('books')) || [];
    const reportData = generateReportData(books);
    
    const dataStr = JSON.stringify(reportData, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'bookme-report-' + new Date().toISOString().split('T')[0] + '.json';
    link.click();
    
    addAuditLog('EXPORT', 'Report', 'Generated and downloaded inventory report');
    alert('Report downloaded successfully!');
}

function generateReportData(books) {
    return {
        generatedAt: new Date().toISOString(),
        totalBooks: books.length,
        totalValue: books.reduce((sum, b) => sum + (b.price * b.stock), 0),
        lowStockItems: books.filter(b => b.stock < 10).length,
        byCategory: books.reduce((acc, book) => {
            acc[book.category] = (acc[book.category] || 0) + 1;
            return acc;
        }, {}),
        books: books
    };
}

// ====================
// Update Pagination Info
// ====================
function updatePaginationInfo(count) {
    const tableTotal = document.getElementById('tableTotal');
    const tableStart = document.getElementById('tableStart');
    const tableEnd = document.getElementById('tableEnd');
    
    if (tableTotal) tableTotal.textContent = count;
    if (tableStart) tableStart.textContent = count > 0 ? '1' : '0';
    if (tableEnd) tableEnd.textContent = count;
}

// ====================
// Update Pagination Info
// ====================
function updatePaginationInfo(count) {
    const tableTotal = document.getElementById('tableTotal');
    const tableStart = document.getElementById('tableStart');
    const tableEnd = document.getElementById('tableEnd');
    
    if (tableTotal) tableTotal.textContent = count;
    if (tableStart) tableStart.textContent = count > 0 ? '1' : '0';
    if (tableEnd) tableEnd.textContent = count;
}